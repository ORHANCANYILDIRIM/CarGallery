package cargallery;

public class SportCar extends Car {
    private boolean hasSpoiler;

    public SportCar(String name, int price, boolean hasSpoiler) {
        super(name, price);
        this.hasSpoiler = hasSpoiler;
    }

    public boolean hasSpoiler() {
        return this.hasSpoiler;
    }
}
