package cargallery;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class CarGallery extends JFrame {
    private JLabel titleLabel;
    private JTextArea carListTextArea;
    private JButton showPriceButton;

    private HashMap<String, Car> cars;

    public CarGallery() {
        this("Fiyat Listesi");
    }

    public CarGallery(String title) {
        super(title);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(500, 250, 400, 400);
        setSize(400, 400);
        setLayout(new FlowLayout());

        titleLabel = new JLabel("Araba Galerisi Fiyat Listesi");
        add(titleLabel);

        carListTextArea = new JTextArea(10, 30);
        add(carListTextArea);

        showPriceButton = new JButton("Fiyatları Göster");
        add(showPriceButton);

        showPriceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPrices();
            }
        });

        cars = new HashMap<>();
        cars.put("Volkswagen Passat Variant", new Car("Volkswagen Passat Variant", 1200000));
        cars.put("Nissan Qashqai", new Car("Nissan Qashqai", 700000));
        cars.put("BMW 420i Coupé", new SportCar("BMW 420i Coupé", 2400000, true));
        cars.put("Audi A3", new Car("Audi A3", 1500000));
        cars.put("Mercedes-Benz E-Class", new Car("Mercedes-Benz E-Class", 2000000));
        cars.put("Mitsubishi L200 Tornado", new Car("Mitsubishi L200 Tornado", 900000));
        cars.put("BMW X5", new SportCar("BMW X5", 2500000, true));
        cars.put("Volvo XC90", new Car("Volvo XC90", 5000000));
        

        StringBuilder carList = new StringBuilder();
        for (String car : cars.keySet()) {
            carList.append(car).append("\n");
        }
        carListTextArea.setText(carList.toString());
    }

    private void showPrices() {
        StringBuilder priceList = new StringBuilder();
        for (String carName : cars.keySet()) {
            Car car = cars.get(carName);
            priceList.append(car.getName()).append(" : ").append(car.getPrice()).append(" TL").append("\n").append("\n");
        }
        carListTextArea.setText(priceList.toString());
    }
}
